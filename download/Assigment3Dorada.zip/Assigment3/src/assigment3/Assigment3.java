
package assigment3;


import java.time.LocalDate;
import java.util.ArrayList;

public class Assigment3 {
    public static void main(String[] args) {
        ArrayList<Person> people = new ArrayList<Person>();
        String text = "John.Davidson/05082004/Belgrade Michael.Barton/01011998/Krakov Ivan.Perkinson/23051986/Moscow";
        String[] lista = text.split(" "); //Lista ljudi
        for (int i = 0; i < lista.length; i++) {
            String[] infomation = lista[i].split("/"); //Name, Surname, Date, BirthPlace
            String[] x = infomation[0].split("\\.");
            String name = x[0];
            String surname = x[1];
            char[] birthdayPreparationArray = infomation[1].toCharArray();
            String birthPlace = infomation[2];

            ////////////////////////////////////////////
            //Godina
            StringBuilder sbYear = new StringBuilder();
            sbYear.append(birthdayPreparationArray[4]);
            sbYear.append(birthdayPreparationArray[5]);
            sbYear.append(birthdayPreparationArray[6]);
            sbYear.append(birthdayPreparationArray[7]);
            int bYear = Integer.parseInt(sbYear.toString());

            //Mesec
            StringBuilder sbMonth = new StringBuilder();
            sbMonth.append(birthdayPreparationArray[2]);
            sbMonth.append(birthdayPreparationArray[3]);
            int bMonth = Integer.parseInt(sbMonth.toString());

            //Dan
            StringBuilder sbDay = new StringBuilder();
            sbDay.append(birthdayPreparationArray[0]);
            sbDay.append(birthdayPreparationArray[1]);
            int bDay = Integer.parseInt(sbDay.toString());



            LocalDate birtdayDate = LocalDate.of(bYear, bMonth, bDay);

            ///////////////////////////////////////////////////////////
            people.add(new Person(name, surname, birtdayDate,  birthPlace));
        }

        for (int i = 0; i < people.size(); i++) {
            System.out.println(people.get(i).toString());
        }
    }
}
