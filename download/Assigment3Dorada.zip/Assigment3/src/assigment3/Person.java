
package assigment3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Person {
    private String name;
    private String surname;
    private LocalDate birthdayDate;
    private String birthPlace;

    public Person(String name, String surname, LocalDate birthdayDate, String birthPlace) {
        this.name = name;
        this.surname = surname;
        this.birthdayDate = birthdayDate;
        this.birthPlace = birthPlace;
    }

    public String getBirthdayDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd. MMM yyyy.", Locale.forLanguageTag("sr-Latn-RS"));
        String dateToString = birthdayDate.format(formatter);
        return dateToString;
    }



    @Override
    public String toString() {
        return  "Name: " + name + ", " +
                "Surname: " + surname  + ", " +
                "Birthday: " + getBirthdayDate() + ", " +
                "Birth Place: " + birthPlace;
    }
}

