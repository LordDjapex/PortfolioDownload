/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverapp;
import java.io.*;
import java.net.*;
public class Server {


    public static void main(String[] args) {
        try (ServerSocket Server = new ServerSocket(8045);
             Socket serverSocket = Server.accept();
             DataOutputStream out = new DataOutputStream(new BufferedOutputStream(serverSocket.getOutputStream()));
             DataInputStream in = new DataInputStream(new BufferedInputStream(serverSocket.getInputStream()))) {
            while (true) {
                double firstNum = in.readDouble();
                double secondNum = in.readDouble();

                double result = firstNum + secondNum;
                out.writeDouble(result);
                out.flush();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }
}
