/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverapp;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;


public class Client{




    public static void main(String[] args) {

        TextField textField1 = new TextField();
        TextField textField2 = new TextField();
        Button button = new Button("Calculate");
        Button buttonExit = new Button("Exit");
        Label resultLabel = new Label("Result");
        FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT);



        Frame frame = new Frame("Frame");
        frame.setSize(600,400);
        frame.setLayout(flowLayout);
        frame.add(textField1);
        frame.add(textField2);
        frame.add(button);
        frame.add(buttonExit);
        frame.add(resultLabel);
        frame.setVisible(true);

        buttonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent exit) {
                System.exit(0);
            }
        });


        try (Socket clientSocket = new Socket("127.0.0.1", 8045);
             DataInputStream inFromServer = new DataInputStream(clientSocket.getInputStream());
             DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream())) {

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        double firstNum = Double.parseDouble(textField1.getText());
                        double secondNum = Double.parseDouble(textField2.getText());

                        outToServer.writeDouble(firstNum);
                        outToServer.writeDouble(secondNum);
                        outToServer.flush();
                        double result = inFromServer.readDouble();
                        System.out.println(result);
                        resultLabel.setText(Double.toString(result));
                    } catch (Exception e1) {
                        String message = "Please make sure that both of your inputs hold a numeric value";
                        System.out.println(message);
                        resultLabel.setText(message);
                    }
                }
            });

            while (true) {
                Thread.sleep(1000);
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}