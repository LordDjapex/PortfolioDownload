
package serverapp;

public class Starter {
    public static void main(String[] args) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Server.main(args);
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Client.main(args);
            }
        }).start();
    }
}
