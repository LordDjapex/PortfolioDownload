
package sale;

public class Wine extends Product{
    private final double alchoholTax = 0.1d;
    private double volume;

    public Wine(String name, String barcode, double basePrice, double volume) {
        super(name, barcode, basePrice);
        this.volume = volume;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }
    
    @Override
    public double calculatePrice() {
        double priceBeforeAdditionalTax = super.calculatePrice();
        return  priceBeforeAdditionalTax + priceBeforeAdditionalTax * alchoholTax; 
    }

    @Override
    public String toString() {
        return super.toString() + "\n Volume "+ getVolume();
    }
    
    
    
    
}
