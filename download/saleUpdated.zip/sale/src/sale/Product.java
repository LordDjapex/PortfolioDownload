
package sale;
public abstract class Product {
    private String name;
    private String barcode;
    private double basePrice;
    private final double pdv = 0.2d;

    public Product(String name, String barcode, double basePrice) {
        this.name = name;
        this.barcode = barcode;
        this.basePrice = basePrice;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }


    public String getName() {
        return name;
    }

    public String getBarcode() {
        return barcode;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public double calculatePrice() {
        double finalPrice = getBasePrice() + getBasePrice() * pdv;
        return finalPrice;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + " \n Barcode: " + getBarcode() + "\n Price: " + calculatePrice();
    }
    
    
}

