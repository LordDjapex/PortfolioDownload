/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sale;

public class Sale {
    public static void main(String[] args) {
        Chocolate coko = new Chocolate("Kokolino", "24543341313", 300, 80);
        System.out.println(coko.toString());
        
        Wine vino = new Wine("Zdrebac", "352455255", 240, 0.75);
        System.out.println(vino.toString());
    }
    
}
