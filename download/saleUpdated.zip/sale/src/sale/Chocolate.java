
package sale;

public class Chocolate extends Product {
    private double weight;

    public Chocolate(String name, String barcode, double basePrice, double weight) {
        super(name, barcode, basePrice);
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public double calculatePrice() {
        return super.calculatePrice(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return super.toString() + "\n Weight: " + getWeight() + "\n";
    }
    
    
}
