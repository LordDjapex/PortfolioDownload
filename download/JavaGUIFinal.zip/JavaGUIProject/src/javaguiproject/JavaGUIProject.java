package javaguiproject;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.ScheduledExecutorService;

public class JavaGUIProject {
    private static int cycle = 2;
    private static boolean timerTruth = true;
    private static ArrayList<Color> colorsArrayList = new ArrayList<>();
    private static DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    private static int speedChange;
    private static ScheduledExecutorService scheduledExecutorService;


    public static void main(String[] args) {

        boolean firstPanelBool = false;
        JButton settingsButton = new JButton();
        JButton closeButton = new JButton();
        settingsButton.setText("Settings");
        closeButton.setText("Close");
        JFrame frame = new JFrame("Option dialog");

        frame.setLayout(new FlowLayout());
        frame.add(new JLabel("Choose option"));
        frame.add(settingsButton);
        frame.add(closeButton);
        frame.setSize(new Dimension(500, 500));

        frame.setVisible(true);

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JPanel firstPanel = new JPanel();
                firstPanel.setPreferredSize(new Dimension(1600, 1200));
                frame.add(firstPanel);
                frame.setContentPane(firstPanel);
                firstPanel.setLayout(new FlowLayout());

                Dimension radioButtonDimension = new Dimension(30, 30);
                Dimension textFieldDimenssion = new Dimension(100, 40);

                ButtonGroup buttonGroup = new ButtonGroup();
                JRadioButton onTimeRadioButton = new JRadioButton();
                onTimeRadioButton.setMaximumSize(radioButtonDimension);
                TextField onTimeTextField = new TextField();
                onTimeTextField.setPreferredSize(textFieldDimenssion);
                Label onTimeLabel = new Label("On time");

                JRadioButton countdownRadioButton = new JRadioButton();
                countdownRadioButton.setMaximumSize(radioButtonDimension);
                TextField countdownTextField = new TextField();
                countdownRadioButton.setPreferredSize(textFieldDimenssion);
                Label countdownLabel = new Label("Countdown");

                buttonGroup.add(onTimeRadioButton);
                buttonGroup.add(countdownRadioButton);
                buttonGroup.clearSelection();
                JButton start = new JButton();
                start.setText("Start");

                Button colorChooserButton = new Button();
                colorChooserButton.setLabel("Choose Color");
                Label colorChooserColorLabel = new Label("No color selected");
                JColorChooser colorChooser = new JColorChooser();
                Button colorAddButton = new Button();
                colorAddButton.setLabel("Add Color");

                Timer timerForColors = new Timer(50, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        colorChooserColorLabel.setForeground(colorChooser.getColor());
                    }
                });

                Button stopButtonOnSecondPanel = new Button();
                stopButtonOnSecondPanel.setLabel("Stop");

                Label speedLabel = new Label("Speed");
                Integer[] comboBox = {1, 2, 3, 4, 5};
                JComboBox speedSpiner = new JComboBox(comboBox);
                speedSpiner.setSelectedIndex(0);

                firstPanel.add(speedLabel);
                firstPanel.add(speedSpiner);
                firstPanel.add(onTimeRadioButton);
                firstPanel.add(onTimeTextField);
                firstPanel.add(onTimeLabel);
                firstPanel.add(countdownRadioButton);
                firstPanel.add(countdownTextField);
                firstPanel.add(countdownLabel);
                firstPanel.add(colorChooserButton);
                firstPanel.add(colorChooserColorLabel);
                firstPanel.add(stopButtonOnSecondPanel);

                firstPanel.add(start);
                frame.pack();

                firstPanel.setVisible(true);

                JFrame secondframe = new JFrame();
                JPanel secondPanel = new JPanel();
                secondframe.add(secondPanel);
                secondPanel.setPreferredSize(new Dimension(1000, 900));
                secondframe.setContentPane(secondPanel);
                secondPanel.setLayout(new FlowLayout());
                secondPanel.setOpaque(true);
                secondframe.pack();

                start.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {

                        speedChange = Integer.parseInt((String) speedSpiner.getSelectedItem().toString()) * 1000;
                        Timer timer = new Timer(speedChange, new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                try {
                                    if (timerTruth) {
                                        cycle = colorsArrayList.size();
                                        timerTruth = false;
                                    }
                                    int trueColorNumber = cycle % colorsArrayList.size();
                                    if (trueColorNumber > colorsArrayList.size()) {
                                        cycle = colorsArrayList.size();
                                        trueColorNumber = cycle % colorsArrayList.size();
                                    }
                                    secondframe.getContentPane().setBackground(colorsArrayList.get(trueColorNumber));
                                    cycle++;
                                } catch (Exception y) {
                                    System.out.println("Timer was interrupted");
                                    y.printStackTrace();
                                }
                            }
                        });

                        boolean vibeCheck = false;
                        if (buttonGroup.isSelected(onTimeRadioButton.getModel())) {
                                try {
                                    Date date = dateFormat.parse(onTimeTextField.getText());
                                    vibeCheck = true;
                                    String dateToString = date.toString();
                                    String[] helpingArray = dateToString.split(" ");
                                    String[] dateArray = helpingArray[3].split(":");
                                    int hour = Integer.parseInt(dateArray[0]);
                                    int minutes = Integer.parseInt(dateArray[1]);
                                    int seconds = Integer.parseInt(dateArray[2]);
                                    for (String s : dateArray) {
                                        System.out.println(s);
                                    }
                                    long delay = ChronoUnit.MILLIS.between(LocalTime.now(), LocalTime.of(hour, minutes, seconds));
                                    if (delay < 0) {
                                        throw new Exception();
                                    }
                                    System.out.println(delay);
                                    timer.setInitialDelay((int) delay);
                                } catch (Exception e1) {
                                    System.out.println("Please enter a valid date in format HH:mm:ss");
                                    vibeCheck = false;
                                }
                            }


                        else if (buttonGroup.isSelected(countdownRadioButton.getModel())) {
                            vibeCheck = false;
                            try {
                                vibeCheck = true;
                                int time = Integer.parseInt(countdownTextField.getText());
                                timer.setInitialDelay(time * 1000);
                                if (time < 0) {
                                    throw new Exception();
                                }
                            } catch (Exception e2) {
                                System.out.println("Please enter an int");
                                vibeCheck = false;
                            }
                        }

                        if (vibeCheck) {
                            timerForColors.stop();
                            secondframe.getContentPane().setBackground(Color.white);
                            secondframe.setVisible(true);
                            secondPanel.setVisible(true);

                            onTimeRadioButton.setEnabled(false);
                            countdownRadioButton.setEnabled(false);
                            speedSpiner.setEnabled(false);
                            start.setEnabled(false);
                            colorAddButton.setEnabled(false);
                            colorChooserButton.setEnabled(false);
                            timer.start();

                        }

                        stopButtonOnSecondPanel.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                if (secondframe.isVisible()) {
                                    timer.stop();
                                    secondframe.setVisible(false);
                                    colorsArrayList = new ArrayList<>();
                                    onTimeRadioButton.setEnabled(true);
                                    countdownRadioButton.setEnabled(true);
                                    speedSpiner.setEnabled(true);
                                    start.setEnabled(true);
                                    colorAddButton.setEnabled(true);
                                    colorChooserButton.setEnabled(true);
                                    colorChooserColorLabel.setText("No color chosen");
                                }
                            }
                        });

                    }
                });


                colorChooserButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        firstPanel.add(colorChooser);
                        firstPanel.add(colorAddButton);
                        timerForColors.start();
                    }
                });

                colorAddButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        colorsArrayList.add(colorChooser.getColor());
                        colorChooserColorLabel.setText("Color selected");
                    }
                });
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}