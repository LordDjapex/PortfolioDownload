package lastassigmentcorejava;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class LastAssigmentCoreJava {

    public static void main(String[] args) {
        displayMenuControl();

    }

    public static void filesInformation(File file) { //Progress

        try {
            if (file != null) {
                System.out.println(file.getName());
                System.out.println(file.getAbsolutePath());
                System.out.println("Size: " + informationLongBackup(file) / 1024 + " Kb");
                System.out.println(file.getAbsolutePath());
                //Creation Date
                BasicFileAttributes attributes =
                        Files.getFileAttributeView(Paths.get(file.getAbsolutePath()), BasicFileAttributeView.class)
                                .readAttributes();
                FileTime fileTime = attributes.creationTime();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                System.out.println("Creation time = " + simpleDateFormat.format(fileTime.toMillis()));

                //ModifyDate
                FileTime fileTime1 = Files.getLastModifiedTime(Paths.get(file.getAbsolutePath()));
                System.out.println("Modify Time = " + simpleDateFormat.format(fileTime1.toMillis()));
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    } // Finished

    public static void listFiles(File folder) {
        try {
            if (folder.isDirectory()) {
                File[] filesList = folder.listFiles();
                for (int i = 0; i < filesList.length; i++) {
                        System.out.println("Directory: " + filesList[i].getName());
                }
            }
        } catch (Exception e) {
            System.out.println(e.toString());;
        }
    } //Finished

    public static long informationLongBackup(File fileOrFolderInformation) { //Finished
        long folderSize = 0;
        if (fileOrFolderInformation.isDirectory()) {
            File[] folderFileList = fileOrFolderInformation.listFiles();
            for (int i = 0; i < folderFileList.length; i++) {
                folderSize += informationLongBackup(folderFileList[i]);
            }
            return folderSize;
        } else if (fileOrFolderInformation.isFile()) {
            return fileOrFolderInformation.length();
        }
        return 0;
    } // Finished

    public static void createFolder(File folder) {
        try {
            if (folder.mkdirs()) {
                System.out.println("Folder " + folder.getName() + " created.");
            }
            else {
                System.out.println("Folder " + folder.getName() + " already exists.");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    } //Finished

    public static void renameFile(File file, String newName) {
        try {
            File fileWithNewName = new File(file.getParent(), newName);
            if (fileWithNewName.exists()) {
                System.out.println("File already exists");
            }
            boolean success = file.renameTo(fileWithNewName);
            if (success) {
                System.out.println("Sucesfully renamed");
            }
            else {
                System.out.println("File does not exist");
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    } //Finished

    public static void copyFile(Path fileToBeCopied, Path toBeWritten) {
        try {
            Files.copy(fileToBeCopied, Paths.get(toBeWritten + "\\\\" + fileToBeCopied.getFileName()),
                    StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied succesfully");
        } catch (Exception e) {
            System.out.println(e.toString());
    }
} //Finished

    public static void moveFile(Path fileToBeMoved, Path placeToBeMovedTo, StandardCopyOption standardCopyOption) {
        try {
            Files.move(fileToBeMoved, Paths.get(placeToBeMovedTo + "\\\\" + fileToBeMoved.getFileName()),
            standardCopyOption);
            System.out.println("File moved sucessfully");
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    } //Finished

    public static void deleteFile(File fileToBeDeleted) {
        try {
            if (fileToBeDeleted.exists()) {
                fileToBeDeleted.delete();
                System.out.println("File has been deleted sucessfully");
            } else {
                System.out.println("File is non existant");
            }

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    } //Finished

    public static void displayMenuControl() {
        System.out.println("0 -EXIT \n" +
                "1 - LIST files within a folder \n" +
            "2 - INFO about the file/folder \n" +
            "3 - CREATE a folder \n" +
            "4 - RENAME a file/folder \n" +
            "5 - COPY file/folder \n" +
                "6 - MOVE a file/folder \n" +
                "7 - DELETE a file/folder");
        boolean running = true;
        try (Scanner numberScanner = new Scanner(System.in); Scanner wordScanner = new Scanner(System.in)){
            while (running) {
                while (!numberScanner.hasNextInt()) {
                    System.out.println("Please enter an Integer anywhere from 0 to 7");
                    numberScanner.nextLine();
                }
                int insertedNumber = numberScanner.nextInt();
                switch (insertedNumber) {
                    case 0:
                        running = false;
                        break;
                    case 1:
                        System.out.println("Please type in the direction of a file/folder");
                        String filePath = wordScanner.nextLine();
                        filePath.replace("\\", "\\\\");
                        File testedFile = new File(filePath);
                        listFiles(testedFile);
                        break;
                    case 2:
                        System.out.println("Please type in the direction of a file/folder");
                        String filePath2 = wordScanner.nextLine();
                        filePath2.replace("\\", "\\\\");
                        File testedFile2 = new File(filePath2);
                        filesInformation(testedFile2);
                        break;
                    case 3:
                        System.out.println("Please type in a name of a new folder");
                        String filePath3 = wordScanner.nextLine();
                        filePath3.replace("\\", "\\\\");
                        File testedFile3 = new File(filePath3);
                        createFolder(testedFile3);
                        break;
                    case 4:
                        System.out.println("Please type in a direction of wanted file/folder");
                        String filePath4 = wordScanner.nextLine();
                        filePath4.replace("\\", "\\\\");
                        File testedFile4 = new File(filePath4);
                        System.out.println("Please enter a new name");
                        String newName = wordScanner.nextLine();
                        renameFile(testedFile4, newName);
                        break;
                    case 5: //Tested
                        System.out.println("Please type in a direction of wanted file/folder");
                        String filePath5 = wordScanner.nextLine();
                        filePath5.replace("\\", "\\\\");
                        File testedFile5 = new File(filePath5);
                        System.out.println("Please choose a new loocation which the file will be copied to");
                        String pathForANewCopy = wordScanner.nextLine();
                        pathForANewCopy.replace("\\", "\\\\");
                        File filePathForANewCopy = new File(pathForANewCopy);
                        copyFile(testedFile5.toPath(), filePathForANewCopy.toPath());
                        break;
                    case 6:
                        System.out.println("Please type in a direction of wanted file/folder");
                        String filePath6 = wordScanner.nextLine();
                        filePath6.replace("\\", "\\\\");
                        File testedFile6 = new File(filePath6);
                        System.out.println("Please choose a new loocation which the file will be moved to");
                        String pathForANewMovement = wordScanner.nextLine();
                        pathForANewMovement.replace("\\", "\\\\");
                        File filePathForANewMovement = new File(pathForANewMovement);
                        moveFile(testedFile6.toPath(), filePathForANewMovement.toPath(),
                                StandardCopyOption.REPLACE_EXISTING);
                        break;
                    case 7:
                        System.out.println("Please type in the direction of a file/folder you wish to delete");
                        String filePath7 = wordScanner.nextLine();
                        filePath7.replace("\\", "\\\\");
                        File testedFile7 = new File(filePath7);
                        deleteFile(testedFile7);
                        break;
                }

            }
        }catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}